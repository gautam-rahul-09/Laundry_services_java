import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;
import java.util.*;

public class OrderSummaryServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String userId = (String) request.getSession().getAttribute("userEmail");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/laundry", "root", ""); // set correct password if needed

            // ✅ Updated query
            String sql = "SELECT * FROM orders WHERE email = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, userId);
            rs = stmt.executeQuery();

            // Convert ResultSet to List of Maps
            List<Map<String, Object>> orderList = new ArrayList<>();

            while (rs.next()) {
                Map<String, Object> order = new HashMap<>();
                order.put("order_id", rs.getInt("id")); // updated to match your table's primary key
                order.put("service_type", rs.getString("name")); // assuming "name" = service type
                order.put("order_date", rs.getDate("date")); // column is named `date`
                order.put("status", rs.getString("status"));
                order.put("total_price", 0.0); // placeholder, update if you have a price column
                orderList.add(order);
            }

            request.setAttribute("orderDetails", orderList);
            RequestDispatcher dispatcher = request.getRequestDispatcher("orderSummary.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            request.setAttribute("errorMessage", "Error fetching order summary: " + e.getMessage());
            RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
            dispatcher.forward(request, response);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
