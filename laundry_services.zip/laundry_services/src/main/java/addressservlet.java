import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AddressServlet")
public class addressservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Retrieve form data
        String pickupDate = request.getParameter("pickupDate");
        String pickupTime = request.getParameter("pickupTime");
        String contactName = request.getParameter("contactName");
        String contactEmail = request.getParameter("contactEmail");
        String contactPhone = request.getParameter("contactPhone");
        String roadName = request.getParameter("roadName");
        String flatDetails = request.getParameter("flatDetails");
        String fullAddress = request.getParameter("fullAddress");
        String paymentMethod = request.getParameter("paymentMethod");
        
        // Store data in session
        HttpSession session = request.getSession();
        session.setAttribute("pickupDate", pickupDate);
        session.setAttribute("pickupTime", pickupTime);
        session.setAttribute("contactName", contactName);
        session.setAttribute("contactEmail", contactEmail);
        session.setAttribute("contactPhone", contactPhone);
        session.setAttribute("roadName", roadName);
        session.setAttribute("flatDetails", flatDetails);
        session.setAttribute("fullAddress", fullAddress);
        session.setAttribute("paymentMethod", paymentMethod);
        
        // Redirect to checkout page
        response.sendRedirect("checkout.jsp");
    }
}
