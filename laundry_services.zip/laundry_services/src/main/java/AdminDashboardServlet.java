import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Database Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/laundry_db", "root", "password");
            
            // Queries to fetch data
            String totalOrdersQuery = "SELECT COUNT(*) FROM orders";
            String pendingOrdersQuery = "SELECT COUNT(*) FROM orders WHERE status='Pending'";
            String completedOrdersQuery = "SELECT COUNT(*) FROM orders WHERE status='Completed'";
            String totalEarningsQuery = "SELECT SUM(price) FROM orders WHERE status='Completed'";
            
            PreparedStatement ps;
            ResultSet rs;
            
            // Fetch total orders
            ps = conn.prepareStatement(totalOrdersQuery);
            rs = ps.executeQuery();
            int totalOrders = rs.next() ? rs.getInt(1) : 0;
            
            // Fetch pending orders
            ps = conn.prepareStatement(pendingOrdersQuery);
            rs = ps.executeQuery();
            int pendingOrders = rs.next() ? rs.getInt(1) : 0;
            
            // Fetch completed orders
            ps = conn.prepareStatement(completedOrdersQuery);
            rs = ps.executeQuery();
            int completedOrders = rs.next() ? rs.getInt(1) : 0;
            
            // Fetch total earnings
            ps = conn.prepareStatement(totalEarningsQuery);
            rs = ps.executeQuery();
            int totalEarnings = rs.next() ? rs.getInt(1) : 0;
            
            // Set attributes for JSP
            request.setAttribute("totalOrders", totalOrders);
            request.setAttribute("pendingOrders", pendingOrders);
            request.setAttribute("completedOrders", completedOrders);
            request.setAttribute("totalEarnings", totalEarnings);
            
            // Forward to JSP
            RequestDispatcher dispatcher = request.getRequestDispatcher("admindashboard.jsp");
            dispatcher.forward(request, response);
            
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
