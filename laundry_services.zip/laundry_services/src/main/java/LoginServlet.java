import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (PrintWriter out = response.getWriter()) {

            // 🔐 Admin Login Logic (hardcoded)
            if ("admin@mail.com".equals(email) && "admin123".equals(password)) {
                HttpSession session = request.getSession();
                session.setAttribute("userRole", "admin");
                response.sendRedirect("backend/dashboard.jsp");
                return;
            }

            // 🔐 Normal user login via database
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/laundry", "root", "");
                 PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=? AND password=?")) {

                ps.setString(1, email);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("userEmail", email);
                    response.sendRedirect("frontend/homepage.jsp");
                } else {
                    response.sendRedirect("frontend/login.jsp?error=Invalid credentials");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
