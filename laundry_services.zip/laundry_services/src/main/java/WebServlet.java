
public @interface WebServlet {

}
