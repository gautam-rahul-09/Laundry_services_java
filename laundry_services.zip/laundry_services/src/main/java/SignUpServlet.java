import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/signup") // URL pattern matches form action
public class SignUpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public SignUpServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm_password");

        // Check if passwords match
        if (!password.equals(confirmPassword)) {
            response.sendRedirect("frontend/signup.jsp?error=Passwords do not match");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/laundry", "root", "");

            // Step 1: Check if email already exists
            String checkQuery = "SELECT email FROM users WHERE email = ?";
            ps = con.prepareStatement(checkQuery);
            ps.setString(1, email);
            rs = ps.executeQuery();

            if (rs.next()) {
                // Email already registered
                response.sendRedirect("frontend/signup.jsp?error=Email already registered");
                return;
            }

            // Close previous resources
            rs.close();
            ps.close();

            // Step 2: Insert new user
            String insertQuery = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
            ps = con.prepareStatement(insertQuery);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password); // ⚠️ Use hashing in production

            int result = ps.executeUpdate();

            if (result == 1) {
                response.sendRedirect("frontend/login.jsp?message=Signup successful. Please login.");
            } else {
                response.sendRedirect("frontend/signup.jsp?error=Registration failed. Try again.");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("frontend/signup.jsp?error=Something went wrong. Please try again later.");
        } finally {
            // Cleanup
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
