import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@WebServlet("/test-db")
public class DBConnectionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Update your credentials as needed
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/laundry";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; // or your MySQL password

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Try to connect
            Connection con = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);

            out.println("<h2 style='color:green;'>Database Connection Successful ✅</h2>");

            // Close connection
            con.close();

        } catch (ClassNotFoundException e) {
            out.println("<h2 style='color:red;'>JDBC Driver not found ❌</h2>");
            e.printStackTrace(out);
        } catch (SQLException e) {
            out.println("<h2 style='color:red;'>Database Connection Failed ❌</h2>");
            e.printStackTrace(out);
        }
    }
}
